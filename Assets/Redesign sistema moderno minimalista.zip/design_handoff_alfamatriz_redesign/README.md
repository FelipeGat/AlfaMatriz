# Handoff: Redesign do AlfaMatriz + nova identidade

> Pacote de entrega para implementação assistida por Claude Code no repositório **AlfaMatriz** (Laravel 12 + Blade + Tailwind + Alpine.js).

## Visão geral

Redesign visual completo do painel interno da Alfa Tecnologia (revendas, clientes, sistemas licenciados, faturamento e financeiro), mais a criação do ícone da marca e do lockup ícone + wordmark, no padrão usado no AlfaGym (`gym.alfasolucoes.cloud`).

Objetivos do redesign, na ordem em que foram pedidos:
1. Visual moderno e minimalista.
2. Sidebar **colapsável** (rail de ícones ↔ menu expandido).
3. Tema **dark e light** com alternância.
4. Resolver: visual datado, hierarquia confusa, tabelas pesadas, falta de identidade de marca.

## Sobre os arquivos deste pacote

Os arquivos HTML aqui são **referências de design** — protótipos que mostram aparência e comportamento pretendidos. **Não são código de produção para copiar.** A tarefa é **recriar esses designs dentro do ambiente já existente do AlfaMatriz**: Blade + Tailwind + Alpine.js, seguindo os padrões do repositório (componentes em `resources/views/components`, layouts em `resources/views/layouts`, tokens em `tailwind.config.js`).

Nada de introduzir React, SPA ou build novo. O protótipo usa React internamente apenas como ferramenta de prototipagem.

## Fidelidade

**Alta fidelidade (hi-fi).** Cores, tipografia, espaçamentos, raios e estados estão definitivos. Reproduzir com precisão, usando as classes utilitárias do Tailwind já configuradas no projeto.

---

## Identidade da marca

### Ícone (escolhido: "13c — convergência, afastadas + ângulo aberto")

Duas setas convergindo para um núcleo sólido. Conceito: as revendas convergem para a matriz.

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" fill="none">
  <path d="M5 4l13 15L5 34" stroke="#029caf" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round" opacity=".38"/>
  <path d="M43 4L30 19l13 15" stroke="#029caf" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round" opacity=".38"/>
  <circle cx="24" cy="39" r="6.6" fill="#029caf"/>
</svg>
```

Regras:
- Cor única da marca. No **dark** usar `#2ec9d9`; no **light**, `#017d8c`; em fundo colorido/sólido, branco.
- As setas ficam sempre a 38% de opacidade; o núcleo, 100%.
- Ângulo entre as hastes: **98°**. Vão entre as duas pontas: **12 unidades** do viewBox. Não alterar — essa geometria foi calibrada para não ler como rosto.
- Caixa útil do desenho: `viewBox="2.8 1.8 42.4 43.8"` (viewBox recortado, sem folga). Usar esse recorte quando o ícone for alinhado ao wordmark.

Arquivo pronto: **`favicon.svg`** (neste pacote). Copiar para `public/favicon.svg` e referenciar em `layouts/app.blade.php`:

```blade
<link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
```

### Wordmark

Arquivo **`alfamatriz-wordmark.png`** (neste pacote) — fornecido pelo cliente. Pedir a versão **SVG** ao cliente antes de publicar; o PNG não escala nem troca de cor por tema.

Copiar para `public/brand/alfamatriz-wordmark.png`.

### Lockup horizontal (usado na sidebar)

- Ícone à esquerda, wordmark à direita, alinhados pelo centro vertical.
- Ícone: **28×27px**; wordmark: **15px** de altura, largura automática.
- `gap: 11px`; padding horizontal do container: `18px`; altura da faixa: `62px`.
- Quando a sidebar está colapsada, o wordmark some (`opacity: 0; width: 0`) e só o ícone permanece, centralizado.

---

## Design tokens

Implementar como CSS custom properties num escopo raiz que troca com o tema (recomendado: atributo `data-theme` no `<html>`), e mapear no `tailwind.config.js`.

### Cores — tema dark (padrão)

| Token | Hex | Uso |
|---|---|---|
| `--bg` | `#0a0f11` | fundo da aplicação |
| `--sidebar` | `#0d1417` | fundo da sidebar |
| `--panel` | `#10171a` | cards, tabelas, superfícies |
| `--raised` | `#151f23` | cabeçalho de tabela, inputs, chips |
| `--border` | `rgba(255,255,255,.08)` | todas as bordas e divisores |
| `--ink` | `#e8f0f2` | texto primário |
| `--dim` | `#93a5aa` | texto secundário |
| `--mute` | `#6e7f84` | rótulos, texto terciário |
| `--brand` | `#2ec9d9` | ícones/textos de marca |
| `--brand-solid` | `#029caf` | botões primários |
| `--brand-soft` | `rgba(46,201,217,.13)` | fundo de item ativo, badges |
| `--brand-line` | `rgba(46,201,217,.24)` | borda de destaque |
| `--good` | `#3fbf6a` | positivo / entradas |
| `--warn` | `#e8a045` | atenção / saídas |
| `--bad` | `#d05b4b` | vencido / negativo |
| `--track` | `rgba(255,255,255,.07)` | trilho de barra |
| `--track2` | `#31474d` | série secundária em gráficos |

### Cores — tema light

| Token | Hex |
|---|---|
| `--bg` | `#f6f7f7` |
| `--sidebar` | `#ffffff` |
| `--panel` | `#ffffff` |
| `--raised` | `#f3f6f6` |
| `--border` | `#e4e8e9` |
| `--ink` | `#0d1416` |
| `--dim` | `#5b6b70` |
| `--mute` | `#8c9a9e` |
| `--brand` | `#017d8c` |
| `--brand-solid` | `#029caf` |
| `--brand-soft` | `rgba(2,156,175,.10)` |
| `--brand-line` | `rgba(2,156,175,.22)` |
| `--good` | `#12915a` |
| `--warn` | `#b4671f` |
| `--bad` | `#b03a2e` |
| `--track` | `#eef2f2` |
| `--track2` | `#c8d6d8` |

O `tailwind.config.js` atual já tem uma paleta parecida (`canvas`, `panel`, `brand`…). Substituir pelos valores acima e fazer cada cor apontar para a custom property, para o toggle de tema funcionar sem duplicar classes:

```js
colors: {
  bg: 'var(--bg)', panel: 'var(--panel)', raised: 'var(--raised)',
  ink: 'var(--ink)', dim: 'var(--dim)', mute: 'var(--mute)',
  brand: { DEFAULT: 'var(--brand)', solid: 'var(--brand-solid)', soft: 'var(--brand-soft)', line: 'var(--brand-line)' },
  good: 'var(--good)', warn: 'var(--warn)', bad: 'var(--bad)',
}
```

### Tipografia

| Papel | Fonte | Uso |
|---|---|---|
| Display | **Space Grotesk** 600 | títulos de tela e de card, nome do sistema |
| Texto | **IBM Plex Sans** 400 / 450 / 500 | interface inteira |
| Números | **IBM Plex Mono** 400 / 500 | todo valor monetário, contagem, data, percentual |

Regra dura: **todo número em IBM Plex Mono**. É o que dá o alinhamento das colunas de valor.

Escala usada:

| Elemento | Tamanho / peso |
|---|---|
| Título da tela (h1) | 17px / 600 Space Grotesk, `letter-spacing: -.02em` |
| Eyebrow acima do título | 9.5px / 500 Mono, `letter-spacing: .16em`, uppercase, cor `--mute` |
| Título de card (h3) | 15px / 600 Space Grotesk (14px nos cards menores) |
| Rótulo de KPI | 10.5px / 500 Sans, `letter-spacing: .06em`, uppercase, cor `--mute` |
| Valor de KPI | `clamp(19px, 2.1vw, 26px)` / 500 Mono, `letter-spacing: -.03em`, `white-space: nowrap` |
| Valor de card de resumo | `clamp(17px, 1.6vw, 21px)` / 500 Mono |
| Cabeçalho de tabela | 10.5px / 500 Sans, `letter-spacing: .05em`, uppercase, `--mute`, com `white-space:nowrap; overflow:hidden; text-overflow:ellipsis` |
| Célula de tabela (texto) | 12.5–13px / 400–450 Sans |
| Célula de tabela (valor) | 12.5px / 500 Mono, `nowrap` |
| Item de menu | 13px / 450 Sans |
| Grupo de menu | 9.5px / 500 Mono, `letter-spacing: .16em`, uppercase |

### Espaçamento, raios e sombras

- Raios: **13px** cards principais · **12px** cards de resumo · **9px** botões, inputs, itens de menu · **20px** badges/pílulas · **3px** barras de progresso.
- Padding: cards principais `22px 24px` · cards de resumo `16px 18px` · linhas de tabela `12–13px 20px` · main `24px 26px 40px`.
- Gaps: grades de KPI `14px` · blocos da página `16–18px` · elementos internos `10–12px`.
- **Sem sombras** na interface. Separação é feita por `--border` e por diferença de superfície. Única exceção: overlay de modal e toast (`0 10px 30px -10px rgba(0,0,0,.5)`).
- Bordas sempre `1px solid var(--border)`.

---

## Estrutura da aplicação

### Sidebar (`layouts/navigation.blade.php`)

- Largura **236px** expandida, **68px** colapsada. Transição `width .18s ease`, `overflow: hidden`.
- Estado persistido (Alpine + `localStorage`), para não resetar a cada navegação.
- Topo: faixa de 62px com o lockup (ver acima), borda inferior.
- Meio: navegação rolável, `padding: 14px 12px`, grupos separados por `16px`.
- Grupos e itens (mantém os mesmos de hoje):
  - **Painéis**: Financeiro, Comercial
  - **Comercial**: Revendas, Clientes, Sistemas, Faturamento
  - **Financeiro**: Receitas, Despesas, Despesas Fixas, Caixa
  - **Sistema**: Cadastros
- Item: altura ~38px, `border-radius: 9px`, ícone 18px stroke 1.7 + rótulo 13px, `gap: 11px`.
  - **Ativo**: fundo `--brand-soft`, texto e ícone `--brand`, e um marcador de 3×18px `--brand` colado na borda esquerda (`position:absolute; left:-12px`).
  - **Inativo**: texto `--dim`, ícone `--mute`. Hover: fundo `rgba(255,255,255,.04)` no dark / `#f3f6f6` no light.
- Colapsada: rótulos e títulos de grupo com `opacity: 0; width: 0`; itens centralizados; `title` no elemento para virar tooltip nativo.
- Rodapé: bloco do usuário (avatar circular 30px com inicial, fundo `--brand-soft`, texto `--brand`; nome 12.5px `--ink`; papel 10.5px `--mute`) e o botão **Recolher menu** com a seta `‹` / `›`.

### Header (`layouts/app.blade.php`)

Altura 62px, borda inferior, `padding: 0 26px`:
- Esquerda: eyebrow com o grupo do menu + `h1` com o nome da tela.
- Direita: campo de busca (250×34px, borda `--border`, raio 9px, ícone de lupa 14px, placeholder `--mute`), botão de tema 34×34px (ícone sol/lua) e o menu do usuário existente.

### Conteúdo

`main` com `padding: 24px 26px 40px` e rolagem própria. Cada tela é uma pilha vertical com `gap: 16–18px`.

---

## Telas

### 1. Painel Financeiro (`dashboard.blade.php`)

1. **Grade de KPIs** — `grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px`. Quatro cards: MRR do mês, Saldo em caixa, Entradas do mês, Saídas do mês.
   - Estrutura: rótulo uppercase → valor grande em Mono → linha de apoio (variação percentual colorida + comparação, ou barra de proporção de 6px).
   - Entradas em `--good`, saídas em `--warn`.
   - O valor **nunca quebra**: `white-space: nowrap` + tamanho fluido. Foi um bug recorrente no protótipo; a combinação `auto-fit/minmax(230px)` + `clamp()` + `nowrap` é a solução.
2. **Gráfico Entradas × Saídas** (2/3 da largura) + **coluna lateral** (1/3) com três mini-cards (Revendas ativas, Clientes ativos, Clientes diretos) e um card de destaque "Fechamento do mês" em `--brand-soft` com botão para Faturamento.
   - Gráfico: 6 meses, duas barras por mês (`--brand` e `--track2`), altura 190px, raio 4px no topo, eixo com borda inferior, rótulos dos meses em Mono 11px, mês corrente em `--brand`.
   - Barras lado a lado dentro de cada mês (`display:flex; align-items:flex-end`), com `flex-shrink: 0`, para a altura percentual ser fiel ao dado.
3. **Duas listas**: Receitas pendentes e Despesas em aberto. Linha com descrição (13px `--ink`) + subtítulo (11.5px `--mute`, ou `--bad` quando vencido) à esquerda e valor em Mono à direita; divisor `--border`; link "Ver todas" no cabeçalho.

### 2. Painel Comercial (`dashboard-comercial.blade.php`)

1. Grade de KPIs (mesma anatomia): Sistemas ativos, Clientes ativos, Revendas ativas, MRR estimado.
2. **Ranking de sistemas** — um único card, largura total:
   - Cabeçalho: título + segmented control **Por clientes / Por valor** (fundo `--raised`, item ativo `--brand-soft` + texto `--brand`).
   - Esquerda: **rosca** de 206px (SVG, `r=47`, `stroke-width=11`, girada -90°), um arco por sistema, gap de 2.5 unidades entre arcos; no centro, o total (Mono, `clamp(17px,1.4vw,21px)`) e a unidade em caps.
   - Direita: lista ordenada — marcador de cor de 3px na lateral, posição `01…06` em Mono, nome + categoria, valor e participação alinhados à direita.
   - Paleta dos segmentos: `#029caf`, `#2ec9d9`, `#0f7c8a`, `#7fdce6`, `#e8a045`, `#8fa4a8`.

**Importante:** todos os KPIs de Comercial e do Painel Financeiro devem ser **derivados da mesma consulta** que alimenta os cards de resumo das telas de lista. No protótipo esses números divergiam e pareciam bug.

### 3. Revendas / Clientes / Receitas / Despesas (telas de lista)

Anatomia comum:
1. **Faixa de cards de resumo** — `repeat(auto-fit, minmax(200px,1fr)); gap:12px`. Cada card: rótulo uppercase, valor em Mono, linha de contexto em `--mute` (ex.: "de 12 na base"). Em Clientes, os cards **recalculam conforme os filtros**.
2. **Barra de filtros** (Clientes): busca com ícone, `select` de revenda, segmented control Todos/Ativos/Inativos, e o botão primário à direita.
3. **Tabela** em card com raio 13px e `overflow: hidden`:
   - Cabeçalho com fundo `--raised`, uppercase, truncando com reticências.
   - Linhas em CSS grid com colunas **de largura mínima fixa** para valores e status — nada de `1fr` puro na coluna de dinheiro. Referência (Receitas/Despesas): `minmax(0,2fr) minmax(100px,1.2fr) 88px 96px minmax(112px,.9fr) 104px`.
   - Valores monetários sempre `white-space: nowrap`.
   - Status como pílula: Ativo/Baixada em `--good`, Vencida em `--bad`, Aberta/Inativo em `--raised` + `--dim`.
   - Estado vazio: texto centralizado 13px `--mute`, `padding: 34px`.

Cards de resumo por tela:
- **Revendas**: revendas ativas · clientes na base · MRR de revenda · ticket médio.
- **Clientes**: exibidos · ativos · inativos · soma dos contratos (todos reagindo aos filtros).
- **Receitas**: em aberto · vencidas (`--bad`) · baixadas (`--good`) · total do mês.
- **Despesas**: em aberto · vencidas (`--bad`) · despesas fixas · total do mês (`--warn`).

### 4. Sistemas (`sistemas/index.blade.php`)

Layout **flex com quebra** (`display:flex; flex-wrap:wrap; gap:14px`), não grid fixo:
- **Catálogo** (`flex: 1 1 260px`, sem `max-width`): lista selecionável; cada linha tem nome + contagem, uma barra de proporção de 4px e a categoria em caps. Item selecionado: fundo `--brand-soft` + marcador de 3px na borda esquerda.
- **Detalhe** (`flex: 5 1 420px`):
  - Cabeçalho: avatar 52px com a inicial, nome (20px Space Grotesk), badge "Ativo", subtítulo com categoria/nº de revendas/preço médio e botão "Editar sistema". O container do cabeçalho precisa de `flex-wrap: wrap` e o bloco do título de `flex: 1 1 220px` — sem isso o badge colide com o botão em telas estreitas.
  - Métricas: clientes ativos, MRR atacado, preço médio, participação.
  - **Sparkline** de 6 meses da base de clientes (área `--brand-soft` + linha `--brand` 1.8px `vector-effect="non-scaling-stroke"`, ponto no último mês) com a variação percentual em `--good`.
  - **Preço de atacado por faixa**: 4 faixas (1–50, 51–200, 201–500, 500+), cada uma com nome, preço em Mono e barra proporcional; a faixa vigente recebe badge "Faixa atual" e barra em `--brand`.
  - **Quem revende**: **top 5** por base de clientes, com barra de proporção; contador total no cabeçalho; quando houver mais de 5, rodapé com "N outras revendas · X clientes" + link "Ver todas" para a tela de Revendas. Esse card precisa continuar do mesmo tamanho com 50 revendas.

### 5. Faturamento (`faturamento/index.blade.php`)

1. Cards de resumo: revendas a faturar · clientes considerados · prévia total · vencimento padrão.
2. Card de ação: explicação da competência + botão **Gerar faturamento** (desabilitado, cinza `--raised`, quando não há pendências).
3. Tabela de prévia por revenda: revenda, sistemas, clientes, prévia, situação (Gerada em `--brand-soft` / Pendente em `--raised`).

---

## Interações e comportamento

| Interação | Comportamento |
|---|---|
| Colapsar sidebar | Botão no rodapé alterna 236px ↔ 68px, `width .18s ease`; rótulos somem por opacidade/largura; estado salvo em `localStorage` |
| Alternar tema | Botão no header troca `data-theme` em `<html>`; salvar preferência em `localStorage`; ícone sol ↔ lua |
| Navegação | Links Blade normais; item ativo por `request()->routeIs()` (já existe hoje) |
| Busca de clientes | Filtra por nome, revenda e sistema; combina com filtro de revenda e de status; cards de resumo recalculam |
| Novo cliente | Modal 460px: nome, revenda (select), sistema (select), mensalidade, situação (segmented Ativo/Inativo). Botão de salvar fica cinza e inerte enquanto o nome estiver vazio. Ao salvar: fecha, limpa filtros, o registro aparece no topo e dispara toast |
| Gerar faturamento | Modal de confirmação com a **contagem e o total reais** das revendas pendentes; ao confirmar, gera as cobranças, dispara toast e as novas cobranças passam a aparecer em Receitas |
| Dar baixa | Botão na linha de Receitas/Despesas; ao baixar, status vira "Baixada", o botão fica inerte e os cards de resumo recalculam |
| Toast | Centralizado embaixo, `bottom: 26px`, fundo `--panel`, borda `--brand-line`, ponto `--brand`, entrada `toastIn .22s ease`, some em 2.6s |
| Modal | Overlay `rgba(0,0,0,.55)`, `fadeIn .15s`; caixa com `popIn .18s ease` (`scale(.97) translateY(6px)` → normal) |

Animações: `fadeIn .15s`, `popIn .18s`, `toastIn .22s`, transições de cor/fundo `.12s`, sidebar `.18s`. Nada mais longo que 220ms.

## Estado

- `sidebarExpanded: boolean` (localStorage)
- `theme: 'dark' | 'light'` (localStorage)
- `busca`, `revendaFiltro`, `statusFiltro` — filtros de Clientes (query string, para o filtro sobreviver ao reload e à paginação)
- `metricaRanking: 'clientes' | 'valor'` — Painel Comercial
- `sistemaSelecionado` — Sistemas
- Modais: `modalCliente`, `modalFaturamento`; toast: mensagem + timeout

No Laravel, filtros e seleção devem ir por query string (`?busca=&revenda_id=&status=`), preservando o comportamento server-side atual. Só o que é puramente visual (sidebar, tema, modais, toast) fica no Alpine.

## Responsivo

- Sidebar vira drawer sobreposto abaixo de `lg` (comportamento já existente hoje, manter).
- Grades de KPI e de resumo usam `auto-fit/minmax` — reflow automático.
- Tela de Sistemas empilha catálogo e detalhe quando falta largura (flex-wrap).
- Tabelas: em telas estreitas, rolagem horizontal no container, sem quebrar as colunas de valor.

## Assets

| Arquivo | Origem | Destino sugerido |
|---|---|---|
| `favicon.svg` | criado neste projeto | `public/favicon.svg` |
| `alfamatriz-wordmark.png` | fornecido pelo cliente | `public/brand/alfamatriz-wordmark.png` (pedir SVG) |

Fontes via Bunny Fonts (o projeto já usa): `Space Grotesk` 400/500/600/700, `IBM Plex Sans` 400/500/600, `IBM Plex Mono` 400/500/600. Inter sai.

Ícones: contornos no estilo Heroicons outline, stroke 1.7, 18px na navegação. Os paths usados no protótipo estão em `AlfaMatriz.dc.html` (constante `ICONES`) e os atuais em `components/nav-icon.blade.php`.

## Arquivos deste pacote

| Arquivo | O que é |
|---|---|
| `AlfaMatriz.dc.html` | Protótipo navegável completo — todas as telas, temas, filtros, modais e toasts. **Referência principal.** Abrir no navegador. |
| `AlfaMatriz Redesign.dc.html` | Canvas de exploração: rodadas de ícone e as três direções iniciais de painel. Contexto histórico, não é o alvo. |
| `favicon.svg` | Ícone final da marca. |
| `alfamatriz-wordmark.png` | Wordmark oficial. |

## Arquivos do repositório a alterar

- `tailwind.config.js` — paleta e famílias de fonte
- `resources/css/app.css` — custom properties dos dois temas, estilos base de input/scrollbar
- `resources/views/layouts/app.blade.php` — header, favicon, fontes, atributo de tema
- `resources/views/layouts/navigation.blade.php` — sidebar colapsável e lockup
- `resources/views/components/` — `stat-card`, `bar-chart`, `nav-icon`, `modal`, `primary-button`, `text-input` e um novo `summary-card`
- `resources/views/dashboard.blade.php`, `dashboard-comercial.blade.php`
- `resources/views/{revendas,clientes,cobrancas,contas-pagar,sistemas,faturamento}/index.blade.php`

## Ordem sugerida de implementação

1. Tokens + fontes + toggle de tema (`tailwind.config.js`, `app.css`, `app.blade.php`).
2. Lockup, favicon e sidebar colapsável.
3. Componentes base: `summary-card`, `stat-card`, pílula de status, tabela.
4. Painel Financeiro e Painel Comercial (incluindo o ranking com rosca).
5. Telas de lista (Revendas, Clientes, Receitas, Despesas).
6. Sistemas e Faturamento.
7. Modais, toasts e estados vazios.

## Armadilhas já mapeadas no protótipo

- **Valor monetário quebrando em duas linhas** em coluna de tabela ou card estreito. Sempre `nowrap` + largura mínima na coluna (`minmax(112px, …)`).
- **Cabeçalho de tabela invadindo a coluna vizinha**: dar piso à coluna e truncar o rótulo com reticências.
- **Números divergentes entre telas**: derivar tudo da mesma fonte de dados, inclusive os textos de modal e toast.
- **Badge colidindo com botão** no cabeçalho de Sistemas: `flex-wrap: wrap` + `flex: 1 1 220px` no bloco de título.
- **Barras de gráfico com altura infiel**: barras irmãs lado a lado com `flex-shrink: 0`, nunca empilhadas com percentuais somando mais de 100%.
